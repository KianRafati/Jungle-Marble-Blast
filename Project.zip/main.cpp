#include <bits/stdc++.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL2_gfx.h>
#define PI 3.14159265359


using namespace std;

struct Point
{
    float x , y ;
};

struct Ball
{
    double x , y ;
    char BallColor ;
    double angle ;
    SDL_Texture* texture ;
};

vector <Ball> balls , shootedBalls;


void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian )
{
    SDL_Rect rectangle ;
    rectangle.x = x;
    rectangle.y = y;
    rectangle.w = w;
    rectangle.h = h;
    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);
    if (fill_boolian==1)
        SDL_RenderFillRect(Renderer, &rectangle);
    SDL_RenderDrawRect(Renderer, &rectangle);

}

float getAngle(int x1, int y1, int x2, int y2)
{
    int deltax=x1-x2;
    int deltay=(y1-y2);

    double theta=atan2(deltay,deltax);
    float angle =   theta* (180 / PI)-30;
    return angle >= 0 ? angle : 360 + angle;
}

Point lerp(Point P0 , Point P1 ,float t)
{
    Point P ;
    P.x = (1-t)*P0.x + t*P1.x ;
    P.y = (1-t)*P0.y + t*P1.y ;
    return P ;
}

void BezierCurve(Point P0, Point P1 ,Point P2, Point P3, float t)
{
    Point A = lerp(P0,P1,t) ;
    Point B = lerp(P1,P2,t) ;
    Point C = lerp(P2,P3,t) ;

    Point D = lerp(A,B,t) ;
    Point E = lerp(B,C,t) ;

    Point P = lerp(D,E,t) ;


}

void specialLine(SDL_Renderer* m_renderer ,int x1, int y1,int x2,int y2 , int L , int R , int G, int B)
{
    int n , S ;
    S = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    n = S/L ;
    for(int i = 1 ; i <= 2*n-1 ; i++)
        if(i%2)
            aalineRGBA(m_renderer,x2 - ((x2-x1)/(2*n-1))*i,y2 - ((y2-y1)/(2*n-1))*i,x2 - ((x2-x1)/(2*n-1))*(i-1),y2 - ((y2-y1)/(2*n-1))*(i-1),R,G,B,255) ;
}

void ShowImage (SDL_Renderer *m_renderer,SDL_Texture *image,double x,double y,int width,int height,double angle)
{
    SDL_Rect rectangle{x,y,width,height};
    SDL_QueryTexture(image,NULL,NULL,&width,&height);
    SDL_RenderCopyEx(m_renderer,image,NULL,&rectangle,angle,NULL,SDL_FLIP_NONE);
}


void betterText(
    SDL_Renderer *renderer, string S,
    int x, int y,
    SDL_Color color, int a,
    int size, string Font /*def = arial */)
{
    if (!TTF_WasInit())
        TTF_Init();
    string fontDir = "./fonts/" + Font + ".ttf"; // should have fonts as .ttf files in ./fonts folder from project path
    TTF_Font *font = TTF_OpenFont(fontDir.c_str(), size);
    SDL_Surface *surface = TTF_RenderText_Solid(font, S.c_str(), color);
    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect rect;
    int h, w;
    SDL_QueryTexture(texture, NULL, NULL, &w, &h);
    rect.h = h;
    rect.w = w;
    rect.x = x - w / 2;
    rect.y = y - h / 2;
    SDL_RenderCopy(renderer, texture, NULL, &rect);
    // free resources
    TTF_CloseFont(font);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}
//    SDL_Point M , P3 , P4 ;
//    M.x = (P1.x+P2.x)/2 ; M.y = (P1.y+P2.y)/2 ;
//    int L = sqrt((P1.x-P2.x)*(P1.x-P2.x)+(P1.y-P2.y)*(P1.y-P2.y)) ;
//    P3.x = M.x + rand()%L ; P3.y = M.y + rand()%L ;
//    P4.x = M.x + rand()%L ; P4.y = M.y + rand()%L ;

int main( int argc, char * argv[] )
{
    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN ;   //| SDL_WINDOW_FULLSCREEN_DESKTOP;//SDL_WINDOW_BORDERLESS ;
    SDL_Window * m_window;
    SDL_Renderer * m_renderer;
    SDL_Init( SDL_flags );
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    int W = DM.w;
    int H = DM.h;
    SDL_CreateWindowAndRenderer( W,H , WND_flags, &m_window, &m_renderer );
    SDL_RaiseWindow(m_window);
    SDL_Event event ;
    SDL_Texture * background;
    SDL_Texture *canon ;
    background = IMG_LoadTexture(m_renderer,"background.png");
    canon = IMG_LoadTexture(m_renderer,"frog.png");
    bool inMenu = false , inGame = true , OverMenu = false , startOfGame = true ;
    Point P0 , P1 , P2 , P3 , P4 , P5 ;
    // P0.x =
    srand(time(NULL)) ;
    int canon_x , canon_y , canon_w = 100 , canon_h = 150 ;
    SDL_Point canon_center ;
    canon_x = rand()%(W-canon_w -100) + canon_w ; canon_y = rand()%(H-canon_h-100) + canon_h ;
    canon_center.x = canon_x + canon_w/2 ;
    canon_center.y = canon_y + canon_h/2 ;
    char colors[4] = {'R','G','B','Y'};

        double t = 0 , x0 = 100 /*rand()%W */, y0 = 100 /*rand()%H*/ , a = rand()%10 - 5 , b = rand()%100 + 5 ,c = rand()%10 - 5 ,d= rand()%100+ 5  ;
        double x = x0 , y = y0 ;

    while(inGame)
    {
        Ball aBall ;
        SDL_RenderClear(m_renderer);

        ShowImage(m_renderer,background,0,0,W,H,0);
//        while(x0 < W && y0 < H)
//        {
            while(t<1000)
            {
                filledEllipseRGBA(m_renderer,x,y,20,20,0,0,0,255);
                x -= -1*exp(-a*t/1000)*(b*sin(b*t/1000)+a*cos(b*t/1000)) ;
                y += -1*exp(-c*t/1000)*(c*sin(d*t/1000)-d*cos(d*t/1000)) ;
                t++;
            }
            t = 0 ; x = x0 ; y = y0 ;
//        }-
        int Mouse_x , Mouse_y ;
        SDL_GetMouseState(&Mouse_x,&Mouse_y);
        float angle = getAngle(canon_center.x,canon_center.y,Mouse_x,Mouse_y) -  60;

        ShowImage(m_renderer,canon,canon_x,canon_y,canon_w,canon_h,angle);


        for(int i = 0 ; i < shootedBalls.size() ; i++)
        {
            if((shootedBalls[i].x > W) || (shootedBalls[i].x < 0) || (shootedBalls[i].y > H) || (shootedBalls[i].y < 0) )
                shootedBalls.erase(shootedBalls.begin() + i);

            shootedBalls[i].x += 10*cos(shootedBalls[i].angle*(PI/180)) ; shootedBalls[i].y += 10*sin(shootedBalls[i].angle*(PI/180)) ;
            ShowImage(m_renderer,shootedBalls[i].texture,shootedBalls[i].x -20 ,shootedBalls[i].y-20 ,40,40,0) ;
        }

        if(event.type != SDL_MOUSEBUTTONDOWN)
            specialLine(m_renderer,Mouse_x,Mouse_y,canon_center.x,canon_center.y,30,255,255,255);
        else
            specialLine(m_renderer,Mouse_x,Mouse_y,canon_center.x,canon_center.y,30,255,0,0);



        if(SDL_PollEvent(&event))
        {
            if(event.key.keysym.sym == SDLK_ESCAPE) // pause-menu
            {
                SDL_DestroyWindow( m_window );
                SDL_DestroyRenderer( m_renderer );
                IMG_Quit();
                SDL_Quit();
                break;
            }
            if(event.type == SDL_MOUSEBUTTONDOWN) // ball-shooting
            {
                int selector = rand()%4 ;
                aBall.x = canon_center.x ; aBall.y = canon_center.y;
                aBall.BallColor = colors[selector] ;
                SDL_Texture * ball ;
                switch(selector)
                {
                    case 0:
                        ball = IMG_LoadTexture(m_renderer,"Ball_Red.png") ;
                        break;
                    case 1:
                        ball = IMG_LoadTexture(m_renderer,"Ball_Green.png") ;
                        break;
                    case 2:
                        ball = IMG_LoadTexture(m_renderer,"Ball_Blue.png") ;
                        break;
                    case 3:
                        ball = IMG_LoadTexture(m_renderer,"Ball_Yellow.png") ;
                        break;
                    default:
                        break;
                }
                aBall.texture = ball ;
                aBall.angle = getAngle(canon_center.x,canon_center.y,Mouse_x,Mouse_y) - 150 ;
                shootedBalls.push_back(aBall) ;
            }
        }

        SDL_RenderPresent(m_renderer);

        SDL_Delay(10);
    }


    return 0;

}
